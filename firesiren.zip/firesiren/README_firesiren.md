# firesiren Plugin

## Using

If a fire call comes in that has an attached postal, the nearest fire siren is triggered

## Installation

All plugins follow a similar installation process. For more information, [click here to see our guides.](https://info.sonorancad.com/integration-plugins/integration-plugins)

Download link for the Inferno Collection: Fire/EMS Pager + Fire Siren. [script publicly available.](https://github.com/inferno-collection/Fire-EMS-Pager/releases)